# EDİTH

Ön kamerayla el hareketlerini izleyip telefonda komut çalıştıran Android uygulaması.

## APK nasıl alınır
1. Bu klasörün içindekileri GitHub'da yeni bir depoya yükle (`.github` klasörü dahil).
2. Depoda **Actions** sekmesi -> "APK derle" otomatik çalışır (5-10 dk).
3. Bitince sağdaki **Releases** bölümünden `EDITH.apk` dosyasını telefona indirip yükle.

## İlk kullanım
- Uygulamayı aç, "Hareket algılama" anahtarını aç, kamera iznini ver.
- Erişilebilirlik ayarından "EDİTH"i aç (ana ekran, geri, kaydırma gibi komutlar için).
- Bilgi sekmesinde tüm hareketleri görür, anlamlarını değiştirirsin.


## EDİTH 1.1 güncellemesi
- Siyah-beyaz tema ve küçük elmas görsel detayları.
- Uygulama açma hareketinde uygulama seçici ve uygulama arama alanı.
- Dört yeni kolay el pozu: orta parmak, yüzük parmağı, orta+yüzük, işaret+yüzük.
- Android güncellemesi için versionCode 2 / versionName 1.1.
