package com.elhareket.app

enum class Arrow { NONE, LEFT, RIGHT, UP, DOWN, WAVE }

/** Çizim tarifi: parmaklar sırayla baş, işaret, orta, yüzük, serçe (true = açık). */
class IconSpec(
    val fingers: BooleanArray,
    val rotation: Float = 0f,
    val arrow: Arrow = Arrow.NONE,
    val ring: Boolean = false,
    val twoHands: Boolean = false,
)

private fun h(s: String) = BooleanArray(5) { s[it] == '1' }

enum class Group(val title: String) {
    STATIC("Tutarak yapılan hareketler"),
    TWO("İki elle yapılan hareketler"),
    DYNAMIC("Hareketli hareketler (hızlıca yap)"),
}

enum class Gesture(val title: String, val how: String, val group: Group, val icon: IconSpec) {
    FIST("Yumruk", "Tüm parmaklarını avucuna kapat, baş parmağın da içeride olsun.", Group.STATIC, IconSpec(h("00000"))),
    OPEN_PALM("Açık el", "Beş parmağını da aç, avucunu kameraya doğru tut.", Group.STATIC, IconSpec(h("11111"))),
    INDEX_UP("Bir parmak", "Sadece işaret parmağını yukarı kaldır.", Group.STATIC, IconSpec(h("01000"))),
    VICTORY("Zafer (V)", "İşaret ve orta parmağını V şeklinde aç, diğerleri kapalı.", Group.STATIC, IconSpec(h("01100"))),
    THREE("Üç parmak", "İşaret, orta ve yüzük parmağını aç. Serçe ve baş parmak kapalı.", Group.STATIC, IconSpec(h("01110"))),
    FOUR("Dört parmak", "Baş parmağını avucuna kat, diğer dört parmağını aç.", Group.STATIC, IconSpec(h("01111"))),
    THUMB_UP("Başparmak yukarı", "Yumruk yap, sadece baş parmağını yukarı dik tut.", Group.STATIC, IconSpec(h("10000"))),
    THUMB_DOWN("Başparmak aşağı", "Yumruk yap, sadece baş parmağını aşağı doğru tut.", Group.STATIC, IconSpec(h("10000"), rotation = 180f)),
    OK("OK işareti", "Baş parmak ve işaret parmağının uçlarını birleştirip halka yap, diğer üç parmağı aç.", Group.STATIC, IconSpec(h("00111"), ring = true)),
    ROCK("Rock (boynuz)", "İşaret ve serçe parmağını aç; orta, yüzük ve baş parmak kapalı.", Group.STATIC, IconSpec(h("01001"))),
    SHAKA("Telefon (shaka)", "Baş parmak ve serçe parmağını aç, diğerlerini kapat.", Group.STATIC, IconSpec(h("10001"))),
    L_SHAPE("L işareti", "Baş parmak ve işaret parmağını aç, \"L\" harfi gibi. Diğerleri kapalı.", Group.STATIC, IconSpec(h("11000"))),
    LOVE("Seni seviyorum", "Baş parmak, işaret ve serçe parmağını aç; orta ve yüzük kapalı.", Group.STATIC, IconSpec(h("11001"))),
    PINKY("Serçe parmak", "Sadece serçe parmağını yukarı kaldır.", Group.STATIC, IconSpec(h("00001"))),
    PINCH("Çimdik", "Baş parmak ve işaret parmağının uçlarını birleştir, diğer parmaklar kapalı.", Group.STATIC, IconSpec(h("00000"), ring = true)),
    POINT_RIGHT("Parmak sağa", "İşaret parmağını kendi sağına doğru yatay uzat, diğerleri kapalı.", Group.STATIC, IconSpec(h("01000"), rotation = 90f)),
    POINT_LEFT("Parmak sola", "İşaret parmağını kendi soluna doğru yatay uzat, diğerleri kapalı.", Group.STATIC, IconSpec(h("01000"), rotation = -90f)),
    MIDDLE_UP("Orta parmak", "Sadece orta parmağını aç, diğer parmaklarını kapalı tut.", Group.STATIC, IconSpec(h("00100"))),
    RING_UP("Yüzük parmağı", "Sadece yüzük parmağını aç, diğer parmaklarını kapalı tut.", Group.STATIC, IconSpec(h("00010"))),
    MIDDLE_RING("Orta + yüzük", "Orta ve yüzük parmaklarını aç; işaret ve serçeyi kapalı tut.", Group.STATIC, IconSpec(h("00110"))),
    INDEX_RING("İşaret + yüzük", "İşaret ve yüzük parmaklarını aç; diğerlerini kapalı tut.", Group.STATIC, IconSpec(h("01010"))),

    TWO_OPEN("İki el açık", "İki elini de açıp kameraya göster.", Group.TWO, IconSpec(h("11111"), twoHands = true)),
    TWO_FISTS("İki yumruk", "İki elini de yumruk yapıp kameraya göster.", Group.TWO, IconSpec(h("00000"), twoHands = true)),

    SWIPE_RIGHT("Sağa kaydır", "Açık elini kendi sağına doğru hızlıca savur.", Group.DYNAMIC, IconSpec(h("11111"), arrow = Arrow.RIGHT)),
    SWIPE_LEFT("Sola kaydır", "Açık elini kendi soluna doğru hızlıca savur.", Group.DYNAMIC, IconSpec(h("11111"), arrow = Arrow.LEFT)),
    SWIPE_UP("Yukarı kaydır", "Açık elini hızlıca yukarı kaldır.", Group.DYNAMIC, IconSpec(h("11111"), arrow = Arrow.UP)),
    SWIPE_DOWN("Aşağı kaydır", "Açık elini hızlıca aşağı indir.", Group.DYNAMIC, IconSpec(h("11111"), arrow = Arrow.DOWN)),
    WAVE("El sallama", "Açık elinle sağa sola en az üç kez salla.", Group.DYNAMIC, IconSpec(h("11111"), arrow = Arrow.WAVE)),
}
