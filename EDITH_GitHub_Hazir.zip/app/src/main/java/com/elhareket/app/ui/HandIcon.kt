package com.elhareket.app.ui

import androidx.compose.foundation.Canvas
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import com.elhareket.app.Arrow
import com.elhareket.app.IconSpec
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun HandIcon(
    spec: IconSpec,
    modifier: Modifier = Modifier,
    handColor: Color = MaterialTheme.colorScheme.onSurface,
    accent: Color = MaterialTheme.colorScheme.primary,
) {
    Canvas(modifier) {
        val w = size.width
        val h = size.height
        if (spec.twoHands) {
            drawHand(spec, Offset(w * 0.27f, h * 0.5f), h * 0.62f, handColor, accent)
            drawHand(spec, Offset(w * 0.73f, h * 0.5f), h * 0.62f, handColor, accent)
        } else {
            drawHand(spec, Offset(w / 2, h / 2), h * 0.9f, handColor, accent)
        }
        if (spec.arrow != Arrow.NONE) drawArrow(spec.arrow, accent)
    }
}

private fun DrawScope.drawHand(spec: IconSpec, c: Offset, s: Float, color: Color, accent: Color) {
    rotate(spec.rotation, pivot = c) {
        val pw = s * 0.46f
        val ph = s * 0.36f
        val left = c.x - pw / 2
        val palmTop = c.y - s * 0.02f
        val stroke = s * 0.085f

        drawRoundRect(color, Offset(left, palmTop), Size(pw, ph), CornerRadius(s * 0.1f))

        val lens = floatArrayOf(0.30f, 0.36f, 0.33f, 0.26f)
        for (i in 0..3) {
            val x = left + pw * (0.125f + 0.25f * i)
            val len = if (spec.fingers[i + 1]) s * lens[i] else s * 0.06f
            drawLine(color, Offset(x, palmTop + stroke / 2), Offset(x, palmTop - len), stroke, StrokeCap.Round)
        }

        val base = Offset(left + s * 0.02f, palmTop + ph * 0.55f)
        val tip = if (spec.fingers[0]) Offset(left - s * 0.20f, palmTop - s * 0.02f)
        else Offset(left + s * 0.12f, palmTop + ph * 0.5f)
        drawLine(color, base, tip, stroke, StrokeCap.Round)

        if (spec.ring) {
            drawCircle(
                accent, radius = s * 0.10f,
                center = Offset(left + pw * 0.08f, palmTop - s * 0.10f),
                style = Stroke(width = s * 0.04f),
            )
        }
    }
}

private fun DrawScope.drawArrow(a: Arrow, color: Color) {
    val w = size.width
    val h = size.height
    val sw = h * 0.06f
    fun arrow(from: Offset, to: Offset) {
        drawLine(color, from, to, sw, StrokeCap.Round)
        val ang = atan2(to.y - from.y, to.x - from.x)
        val hl = h * 0.14f
        for (d in floatArrayOf(2.5f, -2.5f)) {
            drawLine(color, to, Offset(to.x + hl * cos(ang + d), to.y + hl * sin(ang + d)), sw, StrokeCap.Round)
        }
    }
    when (a) {
        Arrow.RIGHT -> arrow(Offset(w * 0.15f, h * 0.93f), Offset(w * 0.85f, h * 0.93f))
        Arrow.LEFT -> arrow(Offset(w * 0.85f, h * 0.93f), Offset(w * 0.15f, h * 0.93f))
        Arrow.UP -> arrow(Offset(w * 0.93f, h * 0.9f), Offset(w * 0.93f, h * 0.1f))
        Arrow.DOWN -> arrow(Offset(w * 0.93f, h * 0.1f), Offset(w * 0.93f, h * 0.9f))
        Arrow.WAVE -> {
            arrow(Offset(w * 0.5f, h * 0.07f), Offset(w * 0.9f, h * 0.07f))
            arrow(Offset(w * 0.5f, h * 0.07f), Offset(w * 0.1f, h * 0.07f))
        }
        Arrow.NONE -> {}
    }
}
