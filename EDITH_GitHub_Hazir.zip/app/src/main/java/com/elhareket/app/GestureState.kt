package com.elhareket.app

import kotlinx.coroutines.flow.MutableStateFlow

/** Servis ile ekran arasındaki ortak durum. */
object GestureState {
    val running = MutableStateFlow(false)
    val current = MutableStateFlow<Gesture?>(null)
    val progress = MutableStateFlow(0f)
    val lastAction = MutableStateFlow("")
    val error = MutableStateFlow<String?>(null)
}
